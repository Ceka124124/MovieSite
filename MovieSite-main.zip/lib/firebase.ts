// lib/firebase.ts
import { initializeApp, getApps, getApp } from "firebase/app"
import { getDatabase } from "firebase/database"
import { getStorage } from "firebase/storage"

const firebaseConfig = {
  apiKey: "AIzaSyCTPTwYIuDBmROnBu30dzqoDYvb0pTcXuU",
  authDomain: "chat-9f75c.firebaseapp.com",
  databaseURL: "https://chat-9f75c-default-rtdb.firebaseio.com",
  projectId: "chat-9f75c",
  storageBucket: "chat-9f75c.firebasestorage.app",
  messagingSenderId: "963858978848",
}

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp()
const db = getDatabase(app)
const storage = getStorage(app)

export { db, storage }
