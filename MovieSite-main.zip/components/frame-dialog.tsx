// components/frame-dialog.tsx
// Bu dosya artık kullanılmıyor ve silinebilir.
