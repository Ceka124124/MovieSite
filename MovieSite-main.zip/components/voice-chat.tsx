"use client"

import { useState, useEffect, useRef } from "react"
import io from "socket.io-client"
import { Button } from "@/components/ui/button"
import { Mic, MicOff, PhoneCall, PhoneOff, Loader2 } from "lucide-react"
import { Card } from "@/components/ui/card"

const SOCKET_SERVER_URL = "https://roshka-starvoice.onrender.com" // Provided Socket.IO server URL
const ICE_SERVERS = [{ urls: "stun:stun.l.google.com:19302" }] // STUN server for NAT traversal

interface VoiceChatProps {
  userId: string
  userName: string
}

export function VoiceChat({ userId, userName }: VoiceChatProps) {
  const [isConnected, setIsConnected] = useState(false)
  const [isMicMuted, setIsMicMuted] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const socketRef = useRef<any>(null)
  const localStreamRef = useRef<MediaStream | null>(null)
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null)

  // Initialize Socket.IO and WebRTC connection
  const startVoiceChat = async () => {
    setIsConnecting(true)
    setError(null)

    try {
      // 1. Get local media stream (audio only)
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false })
      localStreamRef.current = stream
      setIsMicMuted(false) // Ensure mic is unmuted when starting

      // 2. Connect to Socket.IO server
      socketRef.current = io(SOCKET_SERVER_URL, {
        transports: ["websocket"], // Prefer WebSocket
        query: { userId, userName }, // Send user info to server
      })

      socketRef.current.on("connect", () => {
        console.log("Socket.IO connected:", socketRef.current.id)
        setIsConnected(true)
        setIsConnecting(false)
      })

      socketRef.current.on("connect_error", (err: any) => {
        console.error("Socket.IO connection error:", err)
        setError("Sesli sohbet sunucusuna bağlanılamadı. Lütfen daha sonra tekrar deneyin.")
        stopVoiceChat() // Clean up on error
      })

      // 3. Create RTCPeerConnection
      peerConnectionRef.current = new RTCPeerConnection({ iceServers: ICE_SERVERS })

      // Add local stream tracks to peer connection
      stream.getTracks().forEach((track) => {
        peerConnectionRef.current?.addTrack(track, stream)
      })

      // Handle ICE candidates
      peerConnectionRef.current.onicecandidate = (event) => {
        if (event.candidate) {
          socketRef.current?.emit("ice-candidate", event.candidate)
        }
      }

      // Handle remote tracks (when another peer adds their stream)
      peerConnectionRef.current.ontrack = (event) => {
        console.log("Remote track received:", event.streams[0])
        // Create an audio element for the remote stream
        const remoteAudio = document.createElement("audio")
        remoteAudio.autoplay = true
        remoteAudio.controls = false // Hide controls
        remoteAudio.srcObject = event.streams[0]
        remoteAudio.id = `remote-audio-${event.streams[0].id}` // Unique ID
        document.body.appendChild(remoteAudio) // Append to body or a specific container
      }

      // Handle signaling messages from other peers
      socketRef.current.on("offer", async (offer: RTCSessionDescriptionInit) => {
        if (!peerConnectionRef.current) return
        await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(offer))
        const answer = await peerConnectionRef.current.createAnswer()
        await peerConnectionRef.current.setLocalDescription(answer)
        socketRef.current?.emit("answer", answer)
      })

      socketRef.current.on("answer", async (answer: RTCSessionDescriptionInit) => {
        if (!peerConnectionRef.current) return
        await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(answer))
      })

      socketRef.current.on("ice-candidate", async (candidate: RTCIceCandidateInit) => {
        if (!peerConnectionRef.current) return
        await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(candidate))
      })

      // Create offer if this is the first peer
      peerConnectionRef.current.onnegotiationneeded = async () => {
        try {
          const offer = await peerConnectionRef.current?.createOffer()
          await peerConnectionRef.current?.setLocalDescription(offer)
          socketRef.current?.emit("offer", offer)
        } catch (err) {
          console.error("Error creating offer:", err)
        }
      }
    } catch (err: any) {
      console.error("Error starting voice chat:", err)
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        setError("Mikrofon erişimi reddedildi. Lütfen tarayıcı ayarlarınızdan izin verin.")
      } else {
        setError("Sesli sohbet başlatılırken bir hata oluştu.")
      }
      setIsConnecting(false)
      stopVoiceChat() // Clean up on error
    }
  }

  // Clean up WebRTC and Socket.IO connections
  const stopVoiceChat = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop())
      localStreamRef.current = null
    }
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close()
      peerConnectionRef.current = null
    }
    if (socketRef.current) {
      socketRef.current.disconnect()
      socketRef.current = null
    }
    // Remove all remote audio elements
    document.querySelectorAll("audio[id^='remote-audio-']").forEach((el) => el.remove())

    setIsConnected(false)
    setIsConnecting(false)
    setIsMicMuted(false)
    setError(null)
  }

  // Toggle microphone mute state
  const toggleMicMute = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = !track.enabled
      })
      setIsMicMuted(!isMicMuted)
    }
  }

  // Cleanup on component unmount
  useEffect(() => {
    return () => {
      stopVoiceChat()
    }
  }, [])

  return (
    <Card className="w-full bg-gray-800 text-white p-3 flex flex-col gap-2">
      <h3 className="text-lg font-semibold border-b border-gray-700 pb-2">Sesli Sohbet</h3>
      {error && <p className="text-red-400 text-sm">{error}</p>}
      <div className="flex items-center justify-between">
        {!isConnected && !isConnecting ? (
          <Button
            onClick={startVoiceChat}
            className="bg-green-600 hover:bg-green-700 text-white flex-grow"
            disabled={isConnecting}
          >
            <PhoneCall className="h-5 w-5 mr-2" /> Sesli Sohbete Katıl
          </Button>
        ) : isConnecting ? (
          <Button className="bg-gray-600 text-white flex-grow" disabled>
            <Loader2 className="h-5 w-5 mr-2 animate-spin" /> Bağlanılıyor...
          </Button>
        ) : (
          <>
            <Button
              onClick={toggleMicMute}
              className={isMicMuted ? "bg-red-600 hover:bg-red-700" : "bg-blue-600 hover:bg-blue-700"}
              title={isMicMuted ? "Mikrofonu Aç" : "Mikrofonu Kapat"}
            >
              {isMicMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </Button>
            <Button onClick={stopVoiceChat} className="bg-red-600 hover:bg-red-700 text-white ml-2 flex-grow">
              <PhoneOff className="h-5 w-5 mr-2" /> Ayrıl
            </Button>
          </>
        )}
      </div>
    </Card>
  )
}
