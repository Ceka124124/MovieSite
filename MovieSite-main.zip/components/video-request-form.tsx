// components/video-request-form.tsx
"use client"

import type React from "react"
import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { push, ref, serverTimestamp } from "firebase/database"
import { db } from "@/lib/firebase"

interface VideoRequestFormProps {
  userId: string
  userName: string
}

export function VideoRequestForm({ userId, userName }: VideoRequestFormProps) {
  const [videoUrl, setVideoUrl] = useState("")
  const [description, setDescription] = useState("")

  const handleSubmitRequest = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!videoUrl.trim()) return

    try {
      await push(ref(db, "room/videoRequests"), {
        userId,
        userName,
        videoUrl,
        description,
        timestamp: serverTimestamp(),
        status: "pending",
      })
      setVideoUrl("")
      setDescription("")
      alert("Video isteğiniz gönderildi!")
    } catch (error) {
      console.error("Error sending video request:", error)
      alert("Video isteği gönderilirken bir hata oluştu.")
    }
  }

  return (
    <Card className="w-full bg-gray-800 text-white p-4 flex flex-col">
      <h3 className="text-lg font-semibold mb-4 border-b border-gray-700 pb-2">Video İsteği Gönder</h3>
      <form onSubmit={handleSubmitRequest} className="space-y-3">
        <Input
          type="url"
          value={videoUrl}
          onChange={(e) => setVideoUrl(e.target.value)}
          placeholder="Video Linki (YouTube, MP4 vb.)"
          required
          className="bg-gray-700 border-none text-white placeholder:text-gray-400"
        />
        <Input
          type="text"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Açıklama (isteğe bağlı)"
          className="bg-gray-700 border-none text-white placeholder:text-gray-400"
        />
        <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700 text-white">
          Video İsteği Gönder
        </Button>
      </form>
    </Card>
  )
}
