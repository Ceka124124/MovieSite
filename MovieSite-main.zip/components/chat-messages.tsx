// components/chat-messages.tsx
"use client"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { useRef, useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowDownCircle, UserIcon } from "lucide-react"

interface ChatMessage {
  id: string
  userId: string
  userName: string
  type: "text" | "gif" | "image" | "video"
  content: string
  timestamp: number
}

interface ChatMessagesUser {
  id: string
  name: string
  profileImage?: string
  frameUrl?: string
}

interface ChatMessagesProps {
  messages: ChatMessage[]
  currentUserId: string
  autoScrollEnabled: boolean
  users: ChatMessagesUser[]
}

export function ChatMessages({ messages, currentUserId, autoScrollEnabled, users }: ChatMessagesProps) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const [showScrollButton, setShowScrollButton] = useState(false)

  // Kullanıcı bilgilerini bul
  const getUserInfo = (userId: string) => {
    return users.find((user) => user.id === userId)
  }

  // Yeni mesaj geldiğinde veya ilk yüklendiğinde otomatik kaydırma
  useEffect(() => {
    const scrollElement = scrollRef.current?.querySelector("[data-radix-scroll-area-viewport]")
    if (scrollElement) {
      const isAlreadyAtBottom = scrollElement.scrollHeight - scrollElement.scrollTop <= scrollElement.clientHeight + 10

      if (autoScrollEnabled && isAlreadyAtBottom) {
        bottomRef.current?.scrollIntoView({ behavior: "smooth" })
        setShowScrollButton(false)
      } else if (!autoScrollEnabled && !isAlreadyAtBottom) {
        setShowScrollButton(true)
      } else if (autoScrollEnabled && !isAlreadyAtBottom) {
        setShowScrollButton(true)
      } else {
        setShowScrollButton(false)
      }
    }
  }, [messages, autoScrollEnabled])

  // Kaydırma olayını dinle ve butonu göster/gizle
  useEffect(() => {
    const scrollElement = scrollRef.current?.querySelector("[data-radix-scroll-area-viewport]")
    if (!scrollElement) return

    const handleScroll = () => {
      const isNotAtBottom = scrollElement.scrollHeight - scrollElement.scrollTop > scrollElement.clientHeight + 10
      setShowScrollButton(isNotAtBottom)
    }

    scrollElement.addEventListener("scroll", handleScroll, { passive: true })
    return () => {
      scrollElement.removeEventListener("scroll", handleScroll)
    }
  }, [])

  const scrollToBottom = () => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" })
    setShowScrollButton(false)
  }

  return (
    <ScrollArea
      className="flex-grow max-h-[60vh] md:max-h-[calc(100vh-250px)] p-4 space-y-4 bg-gray-800 rounded-lg relative"
      ref={scrollRef}
    >
      {messages.map((msg) => {
        const userInfo = getUserInfo(msg.userId)
        const isCurrentUser = msg.userId === currentUserId

        return (
          <div key={msg.id} className={cn("flex", isCurrentUser ? "justify-end" : "justify-start")}>
            <Card
              className={cn(
                "max-w-[70%] p-3 rounded-lg shadow-md",
                isCurrentUser
                  ? "bg-purple-700 text-white rounded-br-none"
                  : "bg-gray-700 text-gray-100 rounded-bl-none",
              )}
            >
              <div className="flex items-center gap-2 mb-1">
                {/* Profil resmi */}
                <div className="relative w-6 h-6 rounded-full overflow-hidden bg-gray-600 flex items-center justify-center">
                  {userInfo?.profileImage ? (
                    <img
                      src={userInfo.profileImage || "/placeholder.svg"}
                      alt={msg.userName}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  ) : (
                    <UserIcon className="w-3 h-3 text-gray-400" />
                  )}
                </div>
                <p className="font-bold text-sm">{msg.userName}:</p>
              </div>

              {msg.type === "text" && <p className="text-sm break-words">{msg.content}</p>}
              {msg.type === "gif" && (
                <img
                  src={msg.content || "/placeholder.svg"}
                  alt="GIF"
                  className="max-w-full h-auto rounded-md"
                  loading="lazy"
                />
              )}
              {(msg.type === "image" || msg.type === "video") && (
                <a href={msg.content} target="_blank" rel="noopener noreferrer">
                  {msg.type === "image" && (
                    <img
                      src={msg.content || "/placeholder.svg"}
                      alt="Uploaded Image"
                      className="max-w-full h-auto rounded-md"
                      loading="lazy"
                    />
                  )}
                  {msg.type === "video" && (
                    <video src={msg.content} controls className="max-w-full h-auto rounded-md" preload="metadata">
                      Tarayıcınız video etiketini desteklemiyor.
                    </video>
                  )}
                  <p className="text-xs text-blue-300 mt-1 truncate">
                    {msg.type === "image" ? "Resim" : "Video"} Görüntüle
                  </p>
                </a>
              )}
              <p className="text-xs text-right mt-1 opacity-70">{new Date(msg.timestamp).toLocaleTimeString()}</p>
            </Card>
          </div>
        )
      })}
      <div ref={bottomRef} />
      {showScrollButton && (
        <Button
          variant="secondary"
          size="icon"
          className="absolute bottom-4 right-4 rounded-full shadow-lg bg-gray-700 text-white hover:bg-gray-600"
          onClick={scrollToBottom}
          aria-label="Aşağı Kaydır"
        >
          <ArrowDownCircle className="h-6 w-6" />
        </Button>
      )}
    </ScrollArea>
  )
}
