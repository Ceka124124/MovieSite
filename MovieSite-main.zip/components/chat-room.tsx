// components/chat-room.tsx
"use client"

import { useState, useEffect } from "react"
import { db } from "@/lib/firebase"
import { ref, onValue, set, serverTimestamp } from "firebase/database"
import { VideoPlayer } from "./video-player"
import { ChatMessages } from "./chat-messages"
import { ChatInput } from "./chat-input"
import { UserList } from "./user-list"
import { VideoRequestForm } from "./video-request-form"
import { AnnouncementBar } from "./announcement-bar"
import { SnowfallEffect } from "./snowfall-effect"
import { SeatLayout } from "./seat-layout"
import { VoiceChat } from "./voice-chat" // VoiceChat import edildi
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { v4 as uuidv4 } from "uuid"
import { useSearchParams } from "next/navigation"
import { Snowflake } from "lucide-react"

interface ChatMessage {
  id: string
  userId: string
  userName: string
  type: "text" | "gif" | "image" | "video"
  content: string
  timestamp: number
}

interface User {
  id: string
  name: string
  isAdmin: boolean
  lastSeen: number
  profileImage?: string
}

export function ChatRoom() {
  const [userId, setUserId] = useState<string | null>(null)
  const [userName, setUserName] = useState("")
  const [isNameSet, setIsNameSet] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const [userProfileImage, setUserProfileImage] = useState<string | undefined>(undefined)

  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [showSnowfall, setShowSnowfall] = useState(true)
  const [autoScrollEnabled, setAutoScrollEnabled] = useState(true)

  const searchParams = useSearchParams()

  // Initialize user ID, name, and profile image from localStorage
  useEffect(() => {
    let storedUserId = null
    let storedUserName = null
    let storedAutoScrollPref = null
    let storedProfileImage = null

    try {
      storedUserId = localStorage.getItem("chatAppUserId")
      storedUserName = localStorage.getItem("chatAppUserName")
      storedAutoScrollPref = localStorage.getItem("chatAppAutoScroll")
      storedProfileImage = localStorage.getItem("chatAppProfileImage") // Get profile image from localStorage
    } catch (e) {
      console.error("Error accessing localStorage:", e)
    }

    if (!storedUserId) {
      storedUserId = uuidv4()
      try {
        localStorage.setItem("chatAppUserId", storedUserId)
      } catch (e) {
        console.error("Error setting userId in localStorage:", e)
      }
    }
    setUserId(storedUserId)

    if (storedUserName) {
      setUserName(storedUserName)
      setIsNameSet(true)
    }

    if (storedProfileImage) {
      setUserProfileImage(storedProfileImage) // Set initial profile image from localStorage
    }

    if (storedAutoScrollPref !== null) {
      setAutoScrollEnabled(JSON.parse(storedAutoScrollPref))
    }

    const urlIsAdmin = searchParams.get("tur") === "admin"
    setIsAdmin(urlIsAdmin)
  }, [searchParams])

  // Firebase listeners
  useEffect(() => {
    if (!userId || !isNameSet) return

    const userRef = ref(db, `room/users/${userId}`)
    const presenceRef = ref(db, ".info/connected")

    // Listen for current user's data (including profile image) from Firebase
    const unsubscribeUserData = onValue(userRef, (snapshot) => {
      const userData = snapshot.val()
      if (userData) {
        // Update local state with Firebase data, prioritizing Firebase if it's newer or different
        setUserProfileImage(userData.profileImage || undefined)
        if (typeof userData.isAdmin === "boolean" && userData.isAdmin !== isAdmin) {
          setIsAdmin(userData.isAdmin)
        }
      }
    })

    const unsubscribePresence = onValue(presenceRef, (snapshot) => {
      if (snapshot.val()) {
        // Use the current state of userProfileImage when updating presence
        const userData = {
          name: userName,
          isAdmin: isAdmin,
          lastSeen: serverTimestamp(),
          profileImage: userProfileImage || null, // Ensure profileImage is sent
        }
        set(userRef, userData)

        // This part ensures the user data is set if it somehow gets deleted from Firebase
        onValue(
          userRef,
          (userSnap) => {
            if (!userSnap.exists()) {
              set(userRef, userData)
            }
          },
          { onlyOnce: true },
        )
      }
    })

    const interval = setInterval(() => {
      // Update lastSeen and ensure profileImage is persisted
      set(ref(db, `room/users/${userId}`), {
        name: userName,
        isAdmin: isAdmin,
        lastSeen: serverTimestamp(),
        profileImage: userProfileImage || null, // Ensure profileImage is sent with every update
      })
    }, 30000)

    const usersListRef = ref(db, "room/users")
    const unsubscribeUsers = onValue(usersListRef, (snapshot) => {
      const data = snapshot.val()
      if (data) {
        const loadedUsers: User[] = Object.keys(data).map((key) => ({
          id: key,
          ...data[key],
        }))
        const activeUsers = loadedUsers.filter((user) => Date.now() - user.lastSeen < 60000)
        setUsers(activeUsers)
      } else {
        setUsers([])
      }
    })

    const messagesRef = ref(db, "room/chatMessages")
    const unsubscribeMessages = onValue(messagesRef, (snapshot) => {
      const data = snapshot.val()
      if (data) {
        const loadedMessages: ChatMessage[] = Object.keys(data)
          .map((key) => ({
            id: key,
            ...data[key],
            timestamp: data[key].timestamp || Date.now(),
          }))
          .sort((a, b) => a.timestamp - b.timestamp)
        setMessages(loadedMessages)
      } else {
        setMessages([])
      }
    })

    return () => {
      unsubscribePresence()
      unsubscribeUserData()
      unsubscribeUsers()
      unsubscribeMessages()
      clearInterval(interval)
    }
  }, [userId, userName, isNameSet, isAdmin, userProfileImage]) // Added userProfileImage to dependencies

  const handleSetName = () => {
    if (userName.trim()) {
      try {
        localStorage.setItem("chatAppUserName", userName)
      } catch (e) {
        console.error("Error setting userName in localStorage:", e)
      }
      setIsNameSet(true)
      if (userId) {
        // When setting name, also ensure profileImage is sent if it exists
        set(ref(db, `room/users/${userId}`), {
          name: userName,
          isAdmin: isAdmin,
          lastSeen: serverTimestamp(),
          profileImage: userProfileImage || null,
        })
      }
    }
  }

  const handleProfileImageChange = (newImageUrl: string | null) => {
    setUserProfileImage(newImageUrl || undefined)
    try {
      if (newImageUrl) {
        localStorage.setItem("chatAppProfileImage", newImageUrl)
      } else {
        localStorage.removeItem("chatAppProfileImage")
      }
    } catch (e) {
      console.error("Error updating profile image in localStorage:", e)
    }
  }

  const toggleSnowfall = () => {
    setShowSnowfall((prev) => !prev)
  }

  const toggleAutoScroll = () => {
    setAutoScrollEnabled((prev) => {
      try {
        localStorage.setItem("chatAppAutoScroll", JSON.stringify(!prev))
      } catch (e) {
        console.error("Error setting autoScroll preference in localStorage:", e)
      }
      return !prev
    })
  }

  if (!isNameSet) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-900 text-white p-4">
        <Card className="p-6 bg-gray-800 shadow-lg rounded-lg w-full max-w-sm">
          <h2 className="text-2xl font-bold mb-4 text-center">Adınızı Girin</h2>
          <Input
            type="text"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            placeholder="Kullanıcı Adınız"
            className="mb-4 bg-gray-700 border-none text-white placeholder:text-gray-400"
          />
          <Button onClick={handleSetName} className="w-full bg-purple-600 hover:bg-purple-700 text-white">
            Sohbete Katıl
          </Button>
        </Card>
      </div>
    )
  }

  if (!userId) {
    return <div className="flex items-center justify-center min-h-screen bg-gray-900 text-white">Yükleniyor...</div>
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col relative overflow-hidden">
      {showSnowfall && <SnowfallEffect isVisible={showSnowfall} />}
      <AnnouncementBar isAdmin={isAdmin} userId={userId} userName={userName} userProfileImage={userProfileImage} />

      <div className="flex flex-col md:flex-row flex-grow p-4 gap-4 z-10">
        {/* Left Column: Video Player & Seats & Video Request Form */}
        <div className="flex flex-col w-full md:w-3/4 gap-4">
          <VideoPlayer isAdmin={isAdmin} userId={userId} />
          <SeatLayout
            currentUserId={userId}
            currentUserName={userName}
            currentUserProfileImage={userProfileImage}
            isAdmin={isAdmin} // Pass isAdmin prop
          />
          {!isAdmin && <VideoRequestForm userId={userId} userName={userName} />}
        </div>

        {/* Right Column: Chat & User List */}
        <div className="flex flex-col w-full md:w-1/4 gap-4">
          {/* Snowfall Toggle Button */}
          <div className="flex justify-end">
            <Button
              variant="outline"
              size="sm"
              onClick={toggleSnowfall}
              className="bg-gray-700 text-white hover:bg-gray-600 border-none"
              title={showSnowfall ? "Kar Efektini Kapat" : "Kar Efektini Aç"}
            >
              <Snowflake className="h-4 w-4 mr-2" />
              {showSnowfall ? "Kar Efektini Kapat" : "Kar Efektini Aç"}
            </Button>
          </div>

          {/* Voice Chat Component */}
          <VoiceChat userId={userId} userName={userName} />

          <div className="flex-grow flex flex-col bg-gray-800 rounded-lg shadow-lg overflow-hidden min-h-0">
            <ChatMessages
              messages={messages}
              currentUserId={userId}
              autoScrollEnabled={autoScrollEnabled}
              users={users}
            />
            <ChatInput
              userId={userId}
              userName={userName}
              isAdmin={isAdmin}
              autoScrollEnabled={autoScrollEnabled}
              toggleAutoScroll={toggleAutoScroll}
            />
          </div>
          <UserList users={users} currentUserId={userId} currentUserIsAdmin={isAdmin} />
        </div>
      </div>
    </div>
  )
}
