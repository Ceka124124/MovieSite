// components/user-list.tsx
"use client"
import { Card } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { UserPlus, UserIcon } from "lucide-react"
import { ref, set } from "firebase/database"
import { db } from "@/lib/firebase"

interface User {
  id: string
  name: string
  isAdmin: boolean
  frameUrl?: string
  profileImage?: string
}

interface UserListProps {
  users: User[]
  currentUserId: string
  currentUserIsAdmin: boolean
}

export function UserList({ users, currentUserId, currentUserIsAdmin }: UserListProps) {
  const handleMakeAdmin = async (userIdToPromote: string) => {
    if (!currentUserIsAdmin) return
    try {
      await set(ref(db, `room/users/${userIdToPromote}/isAdmin`), true)
      alert(`${users.find((u) => u.id === userIdToPromote)?.name} artık yönetici!`)
    } catch (error) {
      console.error("Error promoting user to admin:", error)
      alert("Kullanıcıyı yönetici yaparken bir hata oluştu.")
    }
  }

  return (
    <Card className="w-full h-full bg-gray-800 text-white p-4 flex flex-col">
      <h3 className="text-lg font-semibold mb-4 border-b border-gray-700 pb-2">Odada Aktif Kullanıcılar</h3>
      <ScrollArea className="flex-grow">
        <ul className="space-y-2">
          {users.map((user) => (
            <li key={user.id} className="flex items-center justify-between p-2 rounded-md bg-gray-700">
              <div className="flex items-center gap-2">
                {/* Profil resmi */}
                <div className="relative w-8 h-8 rounded-full overflow-hidden bg-gray-600 flex items-center justify-center">
                  {user.profileImage ? (
                    <img
                      src={user.profileImage || "/placeholder.svg"}
                      alt={user.name}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  ) : (
                    <UserIcon className="w-4 h-4 text-gray-400" />
                  )}
                </div>
                <span className="font-medium">
                  {user.name} {user.isAdmin && "(Yönetici)"}
                  {user.id === currentUserId && " (Sen)"}
                </span>
              </div>

              {currentUserIsAdmin && !user.isAdmin && user.id !== currentUserId && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleMakeAdmin(user.id)}
                  className="text-xs bg-purple-600 hover:bg-purple-700 text-white border-none"
                >
                  <UserPlus className="h-4 w-4 mr-1" /> Yönetici Yap
                </Button>
              )}
            </li>
          ))}
        </ul>
      </ScrollArea>
    </Card>
  )
}
