"use client"

import { useState, useEffect } from "react"
import { ref, onValue, set } from "firebase/database"
import { db } from "@/lib/firebase"
import { Heart, User } from "lucide-react"
import { cn } from "@/lib/utils"

interface Seat {
  id: string
  occupiedBy: string | null
  occupiedByName: string | null
  occupiedByProfileImage?: string | null
}

interface SeatLayoutProps {
  currentUserId: string
  currentUserName: string
  currentUserProfileImage?: string
  isAdmin: boolean // Added isAdmin prop
}

export function SeatLayout({ currentUserId, currentUserName, currentUserProfileImage, isAdmin }: SeatLayoutProps) {
  const [seats, setSeats] = useState<Seat[]>([])
  const [userCurrentSeatId, setUserCurrentSeatId] = useState<string | null>(null)

  // Initialize seats with default values
  useEffect(() => {
    const defaultSeats: Seat[] = []
    for (let i = 1; i <= 6; i++) {
      defaultSeats.push({
        id: `seat-${i}`,
        occupiedBy: null,
        occupiedByName: null,
        occupiedByProfileImage: null,
      })
    }
    setSeats(defaultSeats)
  }, [])

  useEffect(() => {
    const seatsRef = ref(db, "room/seats")
    const unsubscribe = onValue(seatsRef, (snapshot) => {
      const data = snapshot.val()
      const loadedSeats: Seat[] = []
      for (let i = 1; i <= 6; i++) {
        const seatId = `seat-${i}`
        loadedSeats.push({
          id: seatId,
          occupiedBy: data?.[seatId]?.occupiedBy || null,
          occupiedByName: data?.[seatId]?.occupiedByName || null,
          occupiedByProfileImage: data?.[seatId]?.occupiedByProfileImage || null,
        })
      }
      setSeats(loadedSeats)

      const currentUserSeat = loadedSeats.find((seat) => seat.occupiedBy === currentUserId)
      setUserCurrentSeatId(currentUserSeat ? currentUserSeat.id : null)
    })

    return () => unsubscribe()
  }, [currentUserId])

  const handleSeatClick = async (seatId: string) => {
    const seat = seats.find((s) => s.id === seatId)

    if (!seat) return // Should not happen if seats are initialized correctly

    // Admin can kick other users from seats
    if (isAdmin && seat.occupiedBy && seat.occupiedBy !== currentUserId) {
      if (window.confirm(`${seat.occupiedByName} kullanıcısını koltuktan atmak istediğinizden emin misiniz?`)) {
        try {
          await set(ref(db, `room/seats/${seatId}`), {
            occupiedBy: null,
            occupiedByName: null,
            occupiedByProfileImage: null,
          })
          alert(`${seat.occupiedByName} koltuktan atıldı.`)
        } catch (error) {
          console.error("Error kicking user from seat:", error)
          alert("Kullanıcı koltuktan atılırken bir hata oluştu.")
        }
      }
      return
    }

    // User occupies or vacates their own seat
    if (userCurrentSeatId === seatId) {
      // User is already in this seat, vacate it
      await set(ref(db, `room/seats/${seatId}`), {
        occupiedBy: null,
        occupiedByName: null,
        occupiedByProfileImage: null,
      })
      setUserCurrentSeatId(null)
    } else if (!seat.occupiedBy) {
      // Seat is empty, occupy it
      if (userCurrentSeatId) {
        // If user is in another seat, vacate that first
        await set(ref(db, `room/seats/${userCurrentSeatId}`), {
          occupiedBy: null,
          occupiedByName: null,
          occupiedByProfileImage: null,
        })
      }
      await set(ref(db, `room/seats/${seatId}`), {
        occupiedBy: currentUserId,
        occupiedByName: currentUserName,
        occupiedByProfileImage: currentUserProfileImage || null,
      })
      setUserCurrentSeatId(seatId)
    }
    // If seat is occupied by another user and current user is not admin, do nothing.
  }

  const renderSeat = (seat: Seat | undefined, index: number) => {
    // Return early if seat is undefined
    if (!seat) {
      return (
        <div key={`seat-${index + 1}`} className="flex flex-col items-center">
          <div className="relative w-20 h-20 flex items-center justify-center">
            <img
              src="/images/seat-throne.webp"
              alt={`Koltuk ${index + 1}`}
              className="absolute inset-0 w-full h-full object-contain"
              loading="lazy"
            />
            <User className="w-8 h-8 text-gray-400 z-10" />
          </div>
          <span className="text-xs mt-1 text-gray-400 text-center max-w-20 truncate">Koltuk {index + 1}</span>
        </div>
      )
    }

    const isOccupiedByOther = seat.occupiedBy && seat.occupiedBy !== currentUserId
    const isClickable = !isOccupiedByOther || isAdmin // Admins can click occupied seats

    return (
      <div key={seat.id} className="flex flex-col items-center">
        <div
          className={cn(
            "relative w-20 h-20 flex items-center justify-center transition-transform duration-200",
            seat.occupiedBy === currentUserId && "scale-105", // Slight scale for current user
            isClickable ? "cursor-pointer" : "cursor-not-allowed",
          )}
          onClick={() => isClickable && handleSeatClick(seat.id)}
        >
          {seat.occupiedBy ? (
            // When occupied, only show profile picture
            <div className="w-16 h-16 rounded-full overflow-hidden flex items-center justify-center bg-gray-600">
              {seat.occupiedByProfileImage ? (
                <img
                  src={seat.occupiedByProfileImage || "/placeholder.svg"}
                  alt={seat.occupiedByName || "Kullanıcı"}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              ) : (
                <User className="w-8 h-8 text-gray-300" />
              )}
            </div>
          ) : (
            // When empty, show throne image with user icon
            <>
              <img
                src="/images/seat-throne.webp"
                alt={`Koltuk ${index + 1}`}
                className="absolute inset-0 w-full h-full object-contain"
                loading="lazy"
              />
              <User className="w-8 h-8 text-gray-400 z-10" />
            </>
          )}
        </div>
        <span className="text-xs mt-1 text-gray-400 text-center max-w-20 truncate">
          {seat.occupiedByName || `Koltuk ${index + 1}`}
        </span>
      </div>
    )
  }

  // Yan yana koltuklar için kalp kontrolü
  const renderHeartBetweenSeats = (leftSeat: Seat | undefined, rightSeat: Seat | undefined) => {
    if (leftSeat?.occupiedBy && rightSeat?.occupiedBy) {
      return (
        <div className="flex items-center justify-center">
          <Heart className="text-red-500 w-4 h-4" />
        </div>
      )
    }
    return <div className="w-3" /> // Boş alan
  }

  // Don't render until seats are initialized
  if (seats.length === 0) {
    return (
      <div className="w-full bg-gray-800 text-white p-3 rounded-lg">
        <div className="flex flex-col items-center gap-3">
          <div className="text-gray-400 text-sm">Koltuklar yükleniyor...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full bg-gray-800 text-white p-3 rounded-lg">
      <div className="flex flex-col items-center gap-3">
        {/* Üst sıra - 4 koltuk */}
        <div className="flex items-center gap-1">
          {renderSeat(seats[0], 0)}
          {renderHeartBetweenSeats(seats[0], seats[1])}
          {renderSeat(seats[1], 1)}
          <div className="w-6" /> {/* Orta boşluk */}
          {renderSeat(seats[2], 2)}
          {renderHeartBetweenSeats(seats[2], seats[3])}
          {renderSeat(seats[3], 3)}
        </div>

        {/* Alt sıra - 2 koltuk */}
        <div className="flex items-center gap-1">
          {renderSeat(seats[4], 4)}
          {renderHeartBetweenSeats(seats[4], seats[5])}
          {renderSeat(seats[5], 5)}
        </div>
      </div>
    </div>
  )
}
