// components/profile-dialog.tsx
"use client"

import { useEffect } from "react"

import type React from "react"

import { useState, useRef } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Camera, User } from "lucide-react"
import { getStorage, ref as storageRef, uploadBytes, getDownloadURL, deleteObject } from "firebase/storage" // deleteObject import edildi
import { set, ref as dbRef } from "firebase/database"
import { db } from "@/lib/firebase"

interface ProfileDialogProps {
  isOpen: boolean
  onClose: () => void
  userId: string
  userName: string
  currentProfileImage?: string
  onProfileImageChange: (newImageUrl: string | null) => void // Yeni prop eklendi
}

export function ProfileDialog({
  isOpen,
  onClose,
  userId,
  userName,
  currentProfileImage,
  onProfileImageChange,
}: ProfileDialogProps) {
  const [newUserName, setNewUserName] = useState(userName)
  const [profileImage, setProfileImage] = useState<string | null>(currentProfileImage || null)
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Dialog açıldığında mevcut profil resmini state'e yükle
  useEffect(() => {
    setProfileImage(currentProfileImage || null)
    setNewUserName(userName)
  }, [isOpen, currentProfileImage, userName])

  const deleteOldProfileImage = async (oldUrl: string) => {
    if (!oldUrl || oldUrl.includes("/placeholder.svg")) return // Placeholder veya boş URL'leri silme

    try {
      const storage = getStorage()
      // Firebase Storage URL'sinden dosya yolunu çıkar
      const path = oldUrl.split("?")[0].split("/o/")[1]
      if (path) {
        const oldImageRef = storageRef(storage, decodeURIComponent(path))
        await deleteObject(oldImageRef)
        console.log("Eski profil resmi silindi:", oldUrl)
      }
    } catch (error) {
      console.error("Eski profil resmi silinirken hata oluştu:", error)
      // Hata olsa bile yeni resmin yüklenmesini engelleme
    }
  }

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith("image/")) {
      alert("Sadece resim dosyaları yüklenebilir.")
      return
    }

    setIsUploading(true)
    const oldProfileImageUrl = profileImage // Mevcut resmi kaydet

    try {
      const storage = getStorage()
      const imageRef = storageRef(storage, `profile_images/${userId}/${Date.now()}_${file.name}`)
      await uploadBytes(imageRef, file)
      const downloadURL = await getDownloadURL(imageRef)

      setProfileImage(downloadURL) // Yeni resmi state'e ayarla
      onProfileImageChange(downloadURL) // Parent component'e bildir

      // Eski resmi sil
      if (oldProfileImageUrl) {
        await deleteOldProfileImage(oldProfileImageUrl)
      }
    } catch (error) {
      console.error("Profil resmi yüklenirken bir hata oluştu:", error)
      alert("Profil resmi yüklenirken bir hata oluştu.")
    } finally {
      setIsUploading(false)
    }
  }

  const handleSaveProfile = async () => {
    try {
      const updates: any = {
        name: newUserName.trim(),
        lastSeen: Date.now(),
      }

      if (profileImage) {
        updates.profileImage = profileImage
      } else {
        updates.profileImage = null // Eğer resim kaldırıldıysa Firebase'den de sil
      }

      await set(dbRef(db, `room/users/${userId}`), updates)

      // localStorage'u da güncelle
      try {
        if (profileImage) {
          localStorage.setItem("chatAppProfileImage", profileImage)
        } else {
          localStorage.removeItem("chatAppProfileImage")
        }
        localStorage.setItem("chatAppUserName", newUserName.trim())
      } catch (e) {
        console.error("Error updating localStorage:", e)
      }

      alert("Profil başarıyla güncellendi!")
      onClose()
    } catch (error) {
      console.error("Profil güncellenirken bir hata oluştu:", error)
      alert("Profil güncellenirken bir hata oluştu.")
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-gray-800 text-white">
        <DialogHeader>
          <DialogTitle>Profilim</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="flex flex-col items-center gap-4">
            <div className="relative">
              <div className="w-24 h-24 bg-gray-700 rounded-full flex items-center justify-center overflow-hidden">
                {profileImage ? (
                  <img src={profileImage || "/placeholder.svg"} alt="Profil" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-8 h-8 text-gray-400" />
                )}
              </div>
              <Button
                variant="outline"
                size="icon"
                className="absolute -bottom-2 -right-2 rounded-full bg-purple-600 hover:bg-purple-700 text-white border-none"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
              >
                <Camera className="w-4 h-4" />
              </Button>
            </div>
            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
            {isUploading && <p className="text-sm text-gray-400">Yükleniyor...</p>}
          </div>

          <div className="grid gap-2">
            <Label htmlFor="username">Kullanıcı Adı</Label>
            <Input
              id="username"
              value={newUserName}
              onChange={(e) => setNewUserName(e.target.value)}
              placeholder="Yeni kullanıcı adınız"
              className="bg-gray-700 border-none text-white placeholder:text-gray-400"
            />
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} className="bg-gray-700 text-white hover:bg-gray-600">
            İptal
          </Button>
          <Button onClick={handleSaveProfile} className="bg-purple-600 hover:bg-purple-700 text-white">
            Kaydet
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
