// components/chat-input.tsx
"use client"

import type React from "react"
import { useState, useRef } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Send, ImageIcon, Smile, Trash2 } from "lucide-react" // Trash2 import edildi
import { GifPicker } from "./gif-picker"
import { getStorage, ref as storageRef, uploadBytes, getDownloadURL } from "firebase/storage"
import { db } from "@/lib/firebase"
import { push, ref as dbRef, serverTimestamp, set } from "firebase/database" // set import edildi
import { Switch } from "@/components/ui/switch" // Switch import edildi
import { Label } from "@/components/ui/label" // Label import edildi

interface ChatInputProps {
  userId: string
  userName: string
  isAdmin: boolean // Admin prop'u eklendi
  autoScrollEnabled: boolean // autoScrollEnabled prop'u eklendi
  toggleAutoScroll: () => void // toggleAutoScroll prop'u eklendi
}

export function ChatInput({ userId, userName, isAdmin, autoScrollEnabled, toggleAutoScroll }: ChatInputProps) {
  const [message, setMessage] = useState("")
  const [isGifPickerOpen, setIsGifPickerOpen] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const sendMessage = async (type: "text" | "gif" | "image" | "video", content: string) => {
    if (!content.trim()) return

    try {
      await push(dbRef(db, "room/chatMessages"), {
        userId,
        userName,
        type,
        content,
        timestamp: serverTimestamp(),
      })
      setMessage("")
    } catch (error) {
      console.error("Error sending message:", error)
    }
  }

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    sendMessage("text", message)
  }

  const handleGifSelect = (gifUrl: string) => {
    sendMessage("gif", gifUrl)
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const storage = getStorage()
    const fileType = file.type.startsWith("image/") ? "image" : file.type.startsWith("video/") ? "video" : "other"
    if (fileType === "other") {
      alert("Sadece resim ve video dosyaları yüklenebilir.")
      return
    }

    const filePath = `chat_media/${userId}/${Date.now()}_${file.name}`
    const fileStorageRef = storageRef(storage, filePath)

    try {
      await uploadBytes(fileStorageRef, file)
      const downloadURL = await getDownloadURL(fileStorageRef)
      sendMessage(fileType, downloadURL)
    } catch (error) {
      console.error("Error uploading file:", error)
      alert("Dosya yüklenirken bir hata oluştu.")
    }
  }

  const handleClearChat = async () => {
    if (window.confirm("Tüm sohbet mesajlarını silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.")) {
      try {
        await set(dbRef(db, "room/chatMessages"), null) // Tüm mesajları sil
        alert("Sohbet temizlendi!")
      } catch (error) {
        console.error("Error clearing chat:", error)
        alert("Sohbet temizlenirken bir hata oluştu.")
      }
    }
  }

  return (
    <div className="p-4 bg-gray-900 border-t border-gray-700 flex flex-col gap-2">
      <form onSubmit={handleTextSubmit} className="flex items-center gap-2">
        <Input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Mesaj yaz..."
          className="flex-grow bg-gray-700 border-none text-white placeholder:text-gray-400"
        />
        <Button type="submit" size="icon" className="bg-purple-600 hover:bg-purple-700 text-white">
          <Send className="h-5 w-5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsGifPickerOpen(true)}
          className="text-gray-400 hover:text-white"
        >
          <Smile className="h-5 w-5" />
        </Button>
        <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*,video/*" />
        <Button
          variant="ghost"
          size="icon"
          onClick={() => fileInputRef.current?.click()}
          className="text-gray-400 hover:text-white"
        >
          <ImageIcon className="h-5 w-5" />
        </Button>
      </form>

      <div className="flex items-center justify-between text-sm text-gray-400">
        <div className="flex items-center space-x-2">
          <Switch
            id="auto-scroll-toggle"
            checked={autoScrollEnabled}
            onCheckedChange={toggleAutoScroll}
            className="data-[state=checked]:bg-purple-600"
          />
          <Label htmlFor="auto-scroll-toggle">Mesaj Gelince Otomatik Chate Git</Label>
        </div>
        {isAdmin && (
          <Button
            variant="destructive"
            size="sm"
            onClick={handleClearChat}
            className="bg-red-600 hover:bg-red-700 text-white"
          >
            <Trash2 className="h-4 w-4 mr-1" /> Sohbeti Temizle
          </Button>
        )}
      </div>

      <GifPicker isOpen={isGifPickerOpen} onClose={() => setIsGifPickerOpen(false)} onGifSelect={handleGifSelect} />
    </div>
  )
}
