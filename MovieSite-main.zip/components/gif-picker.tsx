// components/gif-picker.tsx
"use client"
import { useState, useEffect, useRef, useCallback } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Loader2, Search, History } from "lucide-react"

interface GifPickerProps {
  onGifSelect: (url: string) => void
  isOpen: boolean
  onClose: () => void
}

const TENOR_API_KEY = "AIzaSyCHhUiDsgGZeJsFlBVvqxaZAY67RCJJiik" // Yeni Tenor API anahtarınız
const CLIENT_KEY = "v0-chat-app" // Uygulamanız için benzersiz bir anahtar
const GIF_HISTORY_KEY = "gif_history" // localStorage anahtarı

export function GifPicker({ onGifSelect, isOpen, onClose }: GifPickerProps) {
  const [currentSearchInput, setCurrentSearchInput] = useState("") // Input'taki anlık değer
  const [searchTerm, setSearchTerm] = useState("trending") // API'ye gönderilecek arama terimi
  const [gifs, setGifs] = useState<string[]>([])
  const [nextPos, setNextPos] = useState("")
  const [loading, setLoading] = useState(false)
  const loadingRef = useRef(loading) // loading state'inin güncel değerini tutmak için ref
  loadingRef.current = loading // Ref'i her render'da güncel tut

  const [showHistory, setShowHistory] = useState(false) // Geçmişi mi yoksa aramayı mı gösteriyor
  const [gifHistory, setGifHistory] = useState<string[]>([]) // Gönderilen GIF'lerin geçmişi
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  // Geçmiş GIF'leri localStorage'dan yükle ve dialog açıldığında trend olanları yükle
  useEffect(() => {
    if (isOpen) {
      const storedHistory = localStorage.getItem(GIF_HISTORY_KEY)
      if (storedHistory) {
        setGifHistory(JSON.parse(storedHistory))
      }
      // Dialog açıldığında ve geçmiş gösterilmiyorsa, varsayılan olarak trend olanları ara
      if (!showHistory) {
        setSearchTerm("trending")
      }
    }
  }, [isOpen, showHistory]) // Sadece isOpen ve showHistory değiştiğinde çalışır

  // gifHistory değiştiğinde localStorage'a kaydet
  useEffect(() => {
    localStorage.setItem(GIF_HISTORY_KEY, JSON.stringify(gifHistory))
  }, [gifHistory])

  // Temel GIF getirme mantığı, loadingRef kullanarak kararlı hale getirildi
  const fetchGifs = useCallback(
    async (query: string, pos = "") => {
      if (loadingRef.current) return // loadingRef.current ile güncel loading durumunu kontrol et
      setLoading(true)
      try {
        const url = new URL(`https://tenor.googleapis.com/v2/search`)
        url.searchParams.append("q", query)
        url.searchParams.append("key", TENOR_API_KEY)
        url.searchParams.append("client_key", CLIENT_KEY)
        url.searchParams.append("limit", "20")
        if (pos) {
          url.searchParams.append("pos", pos)
        } else {
          setGifs([]) // Yeni arama için GIF'leri temizle
        }

        const response = await fetch(url.toString())
        const data = await response.json()

        if (data.results) {
          const newGifs = data.results.map((gif: any) => gif.media_formats.gif.url)
          setGifs((prevGifs) => (pos ? [...prevGifs, ...newGifs] : newGifs))
          setNextPos(data.next || "")
        }
      } catch (error) {
        console.error("Error fetching GIFs:", error)
        // API anahtarı veya ağ hatası durumunda kullanıcıya bilgi ver
        if (error instanceof TypeError && error.message.includes("Failed to fetch")) {
          alert("GIF yüklenirken ağ hatası oluştu. İnternet bağlantınızı kontrol edin.")
        } else {
          alert("GIF yüklenirken bir hata oluştu. Lütfen daha sonra tekrar deneyin.")
        }
      } finally {
        setLoading(false)
      }
    },
    [], // Bağımlılıklar boş, fetchGifs artık kararlı
  )

  // searchTerm değiştiğinde GIF getirme işlemini tetikle (sadece arama modundaysa)
  useEffect(() => {
    if (isOpen && !showHistory && searchTerm.trim() !== "") {
      fetchGifs(searchTerm)
    }
  }, [isOpen, searchTerm, showHistory, fetchGifs]) // fetchGifs kararlı olduğu için döngüye neden olmaz

  // Sonsuz kaydırma mantığı
  const handleScroll = useCallback(() => {
    const scrollElement = scrollAreaRef.current
    if (scrollElement && !loadingRef.current && nextPos && !showHistory) {
      const { scrollTop, scrollHeight, clientHeight } = scrollElement
      // Kullanıcı en alta 100px kala geldiğinde daha fazla GIF yükle
      if (scrollTop + clientHeight >= scrollHeight - 100) {
        fetchGifs(searchTerm, nextPos)
      }
    }
  }, [nextPos, searchTerm, fetchGifs, showHistory]) // loadingRef.current useCallback bağımlılığı değildir

  useEffect(() => {
    const scrollElement = scrollAreaRef.current
    if (scrollElement) {
      scrollElement.addEventListener("scroll", handleScroll)
    }
    return () => {
      if (scrollElement) {
        scrollElement.removeEventListener("scroll", handleScroll)
      }
    }
  }, [handleScroll])

  const handleSearchClick = () => {
    setSearchTerm(currentSearchInput.trim() || "trending") // Input boşsa trend olanları ara
    setShowHistory(false) // Arama moduna geç
  }

  const handleHistoryClick = () => {
    setShowHistory(true) // Geçmiş moduna geç
  }

  const handleGifClick = (url: string) => {
    onGifSelect(url)
    // Geçmişe ekle (eğer zaten yoksa ve geçmiş modunda değilsek)
    if (!gifHistory.includes(url)) {
      setGifHistory((prev) => [url, ...prev].slice(0, 50)) // Son 50 GIF'i tut
    }
    onClose()
  }

  const displayGifs = showHistory ? gifHistory : gifs

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] h-[80vh] flex flex-col bg-gray-800 text-white">
        <DialogHeader>
          <DialogTitle>GIF Seç</DialogTitle>
        </DialogHeader>
        <div className="flex gap-2 mb-4">
          <Input
            type="text"
            placeholder="GIF ara..."
            value={currentSearchInput}
            onChange={(e) => setCurrentSearchInput(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === "Enter") {
                handleSearchClick()
              }
            }}
            className="flex-grow bg-gray-700 border-none text-white placeholder:text-gray-400"
          />
          <Button onClick={handleSearchClick} className="bg-purple-600 hover:bg-purple-700 text-white">
            <Search className="h-5 w-5" />
            <span className="sr-only">Ara</span>
          </Button>
          <Button onClick={handleHistoryClick} className="bg-blue-600 hover:bg-blue-700 text-white">
            <History className="h-5 w-5" />
            <span className="sr-only">Geçmiş</span>
          </Button>
        </div>
        <ScrollArea className="flex-grow pr-4" ref={scrollAreaRef}>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {displayGifs.length === 0 && !loading ? (
              <p className="col-span-full text-center text-gray-400 py-8">
                {showHistory ? "Henüz gönderilmiş GIF yok." : "GIF bulunamadı."}
              </p>
            ) : (
              displayGifs.map((gifUrl, index) => (
                <img
                  key={gifUrl + index} // URL'ler aynı olabilir, index ile benzersiz yap
                  src={gifUrl || "/placeholder.svg"}
                  alt={`GIF ${index}`}
                  className="w-full h-auto object-cover rounded-md cursor-pointer hover:opacity-80 transition-opacity"
                  onClick={() => handleGifClick(gifUrl)}
                  loading="lazy"
                />
              ))
            )}
            {loading &&
              !showHistory && ( // Sadece arama modunda yükleme göster
                <div className="col-span-full flex justify-center py-4">
                  <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
                </div>
              )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}
