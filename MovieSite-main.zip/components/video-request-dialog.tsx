// components/video-request-dialog.tsx
"use client"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { ref, onValue, set } from "firebase/database"
import { db } from "@/lib/firebase"
import { Check, X } from "lucide-react"

interface VideoRequest {
  id: string
  userId: string
  userName: string
  videoUrl: string
  description: string
  timestamp: number
  status: "pending" | "approved" | "rejected"
}

interface VideoRequestDialogProps {
  isOpen: boolean
  onClose: () => void
  currentAdminId: string
}

export function VideoRequestDialog({ isOpen, onClose, currentAdminId }: VideoRequestDialogProps) {
  const [requests, setRequests] = useState<VideoRequest[]>([])

  useEffect(() => {
    if (!isOpen) return

    const requestsRef = ref(db, "room/videoRequests")
    const unsubscribe = onValue(requestsRef, (snapshot) => {
      const data = snapshot.val()
      if (data) {
        const loadedRequests: VideoRequest[] = Object.keys(data).map((key) => ({
          id: key,
          ...data[key],
        }))
        setRequests(loadedRequests.filter((req) => req.status === "pending"))
      } else {
        setRequests([])
      }
    })
    return () => unsubscribe()
  }, [isOpen])

  const handleApproveRequest = async (request: VideoRequest) => {
    try {
      // Update main video state
      await set(ref(db, "room/videoState"), {
        url: request.videoUrl,
        isPlaying: true,
        currentTime: 0,
        lastUpdatedBy: currentAdminId,
      })
      // Mark request as approved
      await set(ref(db, `room/videoRequests/${request.id}/status`), "approved")
      alert(`Video isteği onaylandı: ${request.videoUrl}`)
      onClose() // Close dialog after approval
    } catch (error) {
      console.error("Error approving video request:", error)
      alert("Video isteği onaylanırken bir hata oluştu.")
    }
  }

  const handleRejectRequest = async (requestId: string) => {
    try {
      await set(ref(db, `room/videoRequests/${requestId}/status`), "rejected")
      alert("Video isteği reddedildi.")
    } catch (error) {
      console.error("Error rejecting video request:", error)
      alert("Video isteği reddedilirken bir hata oluştu.")
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] h-[70vh] flex flex-col bg-gray-800 text-white">
        <DialogHeader>
          <DialogTitle>Bekleyen Video İstekleri</DialogTitle>
          <DialogDescription>Kullanıcıların gönderdiği video isteklerini buradan yönetebilirsiniz.</DialogDescription>
        </DialogHeader>
        <ScrollArea className="flex-grow pr-4">
          {requests.length === 0 ? (
            <p className="text-center text-gray-400 py-8">Bekleyen video isteği yok.</p>
          ) : (
            <ul className="space-y-3">
              {requests.map((req) => (
                <li
                  key={req.id}
                  className="bg-gray-700 p-3 rounded-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2"
                >
                  <div>
                    <p className="font-bold text-sm">{req.userName}</p>
                    <p className="text-xs truncate max-w-[200px] sm:max-w-none">
                      <a
                        href={req.videoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-400 hover:underline"
                      >
                        {req.videoUrl}
                      </a>
                    </p>
                    {req.description && <p className="text-xs italic">{req.description}</p>}
                    <p className="text-xs text-gray-400 mt-1">{new Date(req.timestamp).toLocaleString("tr-TR")}</p>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleApproveRequest(req)}
                      className="text-green-400 hover:bg-green-900"
                      title="Onayla"
                    >
                      <Check className="h-5 w-5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRejectRequest(req.id)}
                      className="text-red-400 hover:bg-red-900"
                      title="Reddet"
                    >
                      <X className="h-5 w-5" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}
