// components/video-player.tsx
"use client"

import { useRef, useEffect, useState } from "react"
import { YouTubeEmbed } from "@next/third-parties/google"
import { ref, onValue, set, serverTimestamp } from "firebase/database" // serverTimestamp import edildi
import { db } from "@/lib/firebase"
import { Play, Pause, Volume2, VolumeX, Maximize, Minimize } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { VideoRequestDialog } from "./video-request-dialog"

interface VideoPlayerProps {
isAdmin: boolean
userId: string
}

interface VideoState {
url: string
isPlaying: boolean
currentTime: number
lastUpdatedBy: string
lastAdminUpdateTime?: number // Yeni eklendi
}

const YOUTUBE_REGEX =
/(?:https?://)?(?:www.)?(?:m.)?(?:youtube.com|youtu.be)/(?:watch?v=|embed/|v/|)([\w-]{11})(?:\S+)?/

export function VideoPlayer({ isAdmin, userId }: VideoPlayerProps) {
const videoRef = useRef<HTMLVideoElement>(null)
const [videoState, setVideoState] = useState<VideoState>({
url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ", // Default video
isPlaying: false,
currentTime: 0,
lastUpdatedBy: "",
lastAdminUpdateTime: Date.now(), // Başlangıç değeri
})
const [localTime, setLocalTime] = useState(0)
const [isMuted, setIsMuted] = useState(false)
const [volume, setVolume] = useState(0.5)
const [duration, setDuration] = useState(0)
const [isSeeking, setIsSeeking] = useState(false)
const [newVideoUrlInput, setNewVideoUrlInput] = useState("")
const [isRequestDialogOpen, setIsRequestDialogOpen] = useState(false)
const [isFullScreen, setIsFullScreen] = useState(false)

const videoStateRef = ref(db, "room/videoState")

// 1. Firebase'den video durumu değişikliklerini dinle
useEffect(() => {
const unsubscribe = onValue(videoStateRef, (snapshot) => {
const data: VideoState = snapshot.val()
if (data) {
setVideoState(data)
if (data.url !== newVideoUrlInput || !newVideoUrlInput) {
setNewVideoUrlInput(data.url)
}
}
})
return () => unsubscribe()
}, [newVideoUrlInput])

// 2. Yerel video elementini videoState ile senkronize et (oynatma/duraklatma ve URL değişikliği)
useEffect(() => {
const videoElement = videoRef.current

if (videoElement) {  
  if (videoState.isPlaying && videoElement.paused) {  
    videoElement.play().catch((e) => {  
      console.warn("Video oynatma isteği kesintiye uğradı veya başarısız oldu:", e)  
    })  
  } else if (!videoState.isPlaying && !videoElement.paused) {  
    videoElement.pause()  
  }  

  videoElement.volume = volume  
  videoElement.muted = isMuted  
}

}, [videoState.isPlaying, videoState.url, volume, isMuted])

// 3. Yönetici: Mevcut zamanı periyodik olarak Firebase'e gönder
useEffect(() => {
if (!isAdmin || !videoRef.current) return

const intervalId = setInterval(() => {  
  if (!isSeeking && videoRef.current && videoState.isPlaying) {  
    set(videoStateRef, {  
      ...videoState,  
      currentTime: videoRef.current.currentTime,  
      lastUpdatedBy: userId,  
      lastAdminUpdateTime: serverTimestamp(), // Admin güncellediğinde zaman damgasını kaydet  
    })  
  }  
}, 2000)  

return () => clearInterval(intervalId)

}, [isAdmin, isSeeking, videoState, userId])

// 4. Normal Kullanıcılar: Yerel zamanı Firebase (yöneticinin zamanı) ile akıllıca senkronize et
useEffect(() => {
const videoElement = videoRef.current
if (!videoElement) return

const syncInterval = setInterval(() => {  
  if (!isAdmin && !isSeeking) {  
    const timeDiff = Math.abs(videoElement.currentTime - videoState.currentTime)  
    const adminRecentlyUpdated =  
      videoState.lastAdminUpdateTime && Date.now() - videoState.lastAdminUpdateTime < 5000 // Son 5 saniye içinde admin güncelleme yaptıysa  

    // Eğer admin durdurma/saniye değişikliği yapmamışsa veya fark 6 saniyeden azsa dokunma  
    // Sadece adminin oynatma durumu farklıysa veya zaman farkı büyükse senkronize et  
    if (  
      (videoState.isPlaying !== !videoElement.paused && adminRecentlyUpdated) || // Adminin oynatma durumu farklıysa ve yakın zamanda güncellediyse  
      timeDiff > 6 // Zaman farkı 6 saniyeden büyükse  
    ) {  
      videoElement.currentTime = videoState.currentTime  
      setLocalTime(videoState.currentTime)  
      if (videoState.isPlaying && videoElement.paused) {  
        videoElement.play().catch((e) => console.warn("Video oynatma isteği kesintiye uğradı (sync):", e))  
      } else if (!videoState.isPlaying && !videoElement.paused) {  
        videoElement.pause()  
      }  
      console.log(  
        `Senkronize edildi: Yerel: ${videoElement.currentTime.toFixed(2)}, Admin: ${videoState.currentTime.toFixed(2)}`,  
      )  
    }  
  }  
}, 1000) // Her 1 saniyede bir kontrol et  

return () => clearInterval(syncInterval)

}, [isAdmin, videoState.currentTime, isSeeking, videoState.isPlaying, videoState.lastAdminUpdateTime])

// Tam ekran durumu değişikliklerini dinle
useEffect(() => {
const handleFullScreenChange = () => {
setIsFullScreen(!!document.fullscreenElement)
}

document.addEventListener("fullscreenchange", handleFullScreenChange)  
document.addEventListener("webkitfullscreenchange", handleFullScreenChange)  
document.addEventListener("mozfullscreenchange", handleFullScreenChange)  
document.addEventListener("MSFullscreenChange", handleFullScreenChange)  

return () => {  
  document.removeEventListener("fullscreenchange", handleFullScreenChange)  
  document.removeEventListener("webkitfullscreenchange", handleFullScreenChange)  
  document.removeEventListener("mozfullscreenchange", handleFullScreenChange)  
  document.removeEventListener("MSFullscreenChange", handleFullScreenChange)  
}

}, [])

const handlePlayPause = () => {
if (!isAdmin) return
const newIsPlaying = !videoState.isPlaying
set(videoStateRef, {
...videoState,
isPlaying: newIsPlaying,
currentTime: videoRef.current?.currentTime || 0,
lastUpdatedBy: userId,
lastAdminUpdateTime: serverTimestamp(), // Admin güncellediğinde zaman damgasını kaydet
})
}

const handleSeek = (value: number[]) => {
if (!isAdmin) return
const newTime = value[0]
setIsSeeking(true)
setLocalTime(newTime)
if (videoRef.current) {
videoRef.current.currentTime = newTime
}
}

const handleSeekEnd = (value: number[]) => {
if (!isAdmin) return
const newTime = value[0]
set(videoStateRef, {
...videoState,
currentTime: newTime,
isPlaying: videoState.isPlaying,
lastUpdatedBy: userId,
lastAdminUpdateTime: serverTimestamp(), // Admin güncellediğinde zaman damgasını kaydet
})
setIsSeeking(false)
}

const handleVideoTimeUpdate = () => {
if (videoRef.current && !isSeeking) {
setLocalTime(videoRef.current.currentTime)
}
}

const handleVideoLoadedMetadata = () => {
if (videoRef.current) {
setDuration(videoRef.current.duration)
if (!isAdmin || videoState.currentTime === 0) {
videoRef.current.currentTime = videoState.currentTime
setLocalTime(videoState.currentTime)
}
}
}

const handleVolumeChange = (value: number[]) => {
const newVolume = value[0]
setVolume(newVolume)
if (videoRef.current) {
videoRef.current.volume = newVolume
}
}

const handleMuteToggle = () => {
setIsMuted(!isMuted)
if (videoRef.current) {
videoRef.current.muted = !isMuted
}
}

const formatTime = (seconds: number) => {
const minutes = Math.floor(seconds / 60)
const remainingSeconds = Math.floor(seconds % 60)
return ${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}
}

const handleSetNewVideo = () => {
if (!isAdmin || !newVideoUrlInput.trim()) return
set(videoStateRef, {
url: newVideoUrlInput,
isPlaying: true,
currentTime: 0,
lastUpdatedBy: userId,
lastAdminUpdateTime: serverTimestamp(), // Admin güncellediğinde zaman damgasını kaydet
})
}

const handleFullScreenToggle = () => {
const videoContainer = videoRef.current?.parentElement
if (videoContainer) {
if (!document.fullscreenElement) {
if (videoContainer.requestFullscreen) {
videoContainer.requestFullscreen()
} else if ((videoContainer as any).mozRequestFullScreen) {
;(videoContainer as any).mozRequestFullScreen()
} else if ((videoContainer as any).webkitRequestFullscreen) {
;(videoContainer as any).webkitRequestFullscreen()
} else if ((videoContainer as any).msRequestFullscreen) {
;(videoContainer as any).msRequestFullscreen()
}
} else {
if (document.exitFullscreen) {
document.exitFullscreen()
} else if ((document as any).mozCancelFullScreen) {
;(document as any).mozCancelFullScreen()
} else if ((document as any).webkitExitFullscreen) {
;(document as any).webkitExitFullscreen()
} else if ((document as any).msExitFullscreen) {
;(document as any).msExitFullscreen()
}
}
}
}

const isYouTube = YOUTUBE_REGEX.test(videoState.url)
const youtubeVideoId = isYouTube ? videoState.url.match(YOUTUBE_REGEX)?.[1] : null

return (
<Card className="w-full bg-gray-900 rounded-lg overflow-hidden shadow-xl relative flex flex-col">
{isAdmin && (
<div className="p-3 bg-gray-800 flex flex-col sm:flex-row items-center gap-2 border-b border-gray-700">
<Input
type="url"
value={newVideoUrlInput}
onChange={(e) => setNewVideoUrlInput(e.target.value)}
placeholder="Yeni video linki girin..."
className="flex-grow bg-gray-700 border-none text-white placeholder:text-gray-400"
/>
<Button onClick={handleSetNewVideo} className="bg-purple-600 hover:bg-purple-700 text-white w-full sm:w-auto">
Başlat
</Button>
<Button
onClick={() => setIsRequestDialogOpen(true)}
className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto"
>
İstekler
</Button>
</div>
)}

<div className="relative aspect-video w-full">  
    {isYouTube && youtubeVideoId ? (  
      <YouTubeEmbed  
        videoid={youtubeVideoId}  
        height="100%"  
        width="100%"  
        params={`autoplay=${videoState.isPlaying ? 1 : 0}&start=${Math.floor(  
          videoState.currentTime,  
        )}&controls=${isAdmin ? 1 : 0}&modestbranding=1&rel=0`}  
        style={{ position: "absolute", top: 0, left: 0 }}  
        playlabel="Videoyu Oynat"  
      />  
    ) : (  
      <video  
        key={videoState.url}  
        ref={videoRef}  
        src={videoState.url}  
        controls={isAdmin}  
        muted={isMuted}  
        onTimeUpdate={handleVideoTimeUpdate}  
        onLoadedMetadata={handleVideoLoadedMetadata}  
        className="w-full h-full object-contain bg-black"  
        preload="auto"  
        playsInline  
      >  
        Tarayıcınız video etiketini desteklemiyor.  
      </video>  
    )}  

    <div  
      className={`absolute bottom-0 left-0 right-0 bg-black bg-opacity-70 p-2 flex items-center gap-2 text-white ${  
        isAdmin ? "" : "justify-end"  
      }`}  
    >  
      {isAdmin && !isYouTube && (  
        <>  
          <Button variant="ghost" size="icon" onClick={handlePlayPause} className="text-white hover:bg-white/20">  
            {videoState.isPlaying ? <Pause /> : <Play />}  
          </Button>  
          <Slider  
            value={[localTime]}  
            max={duration}  
            step={1}  
            onValueChange={handleSeek}  
            onValueCommit={handleSeekEnd}  
            className="flex-grow"  
          />  
          <span className="text-xs">  
            {formatTime(localTime)} / {formatTime(duration)}  
          </span>  
          <Button variant="ghost" size="icon" onClick={handleMuteToggle} className="text-white hover:bg-white/20">  
            {isMuted ? <VolumeX /> : <Volume2 />}  
          </Button>  
          <Slider value={[volume]} max={1} step={0.01} onValueChange={handleVolumeChange} className="w-20" />  
        </>  
      )}  
      {!isAdmin && (  
        <Button  
          variant="ghost"  
          size="icon"  
          onClick={handleFullScreenToggle}  
          className="text-white hover:bg-white/20 ml-auto"  
          title={isFullScreen ? "Tam Ekrandan Çık" : "Tam Ekran"}  
        >  
          {isFullScreen ? <Minimize /> : <Maximize />}  
        </Button>  
      )}  
    </div>  
  </div>  

  {isAdmin && (  
    <VideoRequestDialog  
      isOpen={isRequestDialogOpen}  
      onClose={() => setIsRequestDialogOpen(false)}  
      currentAdminId={userId}  
    />  
  )}  
</Card>

)
}
