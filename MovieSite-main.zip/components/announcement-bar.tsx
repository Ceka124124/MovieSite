// components/announcement-bar.tsx
"use client"

import { useState, useEffect } from "react"
import { ref, onValue, set } from "firebase/database"
import { db } from "@/lib/firebase"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { User } from "lucide-react" // ImagePlus kaldırıldı
import { ProfileDialog } from "./profile-dialog"
// import { FrameDialog } from "./frame-dialog" // FrameDialog kaldırıldı

interface AnnouncementBarProps {
  isAdmin: boolean
  userId: string
  userName: string
  userProfileImage?: string
}

export function AnnouncementBar({ isAdmin, userId, userName, userProfileImage }: AnnouncementBarProps) {
  const [announcement, setAnnouncement] = useState("")
  const [editAnnouncement, setEditAnnouncement] = useState("")
  const [isProfileDialogOpen, setIsProfileDialogOpen] = useState(false)
  // const [isFrameDialogOpen, setIsFrameDialogOpen] = useState(false) // State kaldırıldı

  useEffect(() => {
    const announcementRef = ref(db, "room/announcement/message")
    const unsubscribe = onValue(announcementRef, (snapshot) => {
      const data = snapshot.val()
      setAnnouncement(data || "")
      setEditAnnouncement(data || "")
    })

    return () => unsubscribe()
  }, [])

  const handleSaveAnnouncement = () => {
    set(ref(db, "room/announcement/message"), editAnnouncement)
    set(ref(db, "room/announcement/lastUpdated"), Date.now())
  }

  return (
    <>
      <Card className="w-full p-2 bg-gradient-to-r from-purple-600 to-indigo-800 text-white text-center text-sm md:text-base shadow-lg z-40">
        <div className="flex items-center justify-between">
          {/* Sol taraf - Profil butonu */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsProfileDialogOpen(true)}
              className="text-white hover:bg-white/20 flex items-center gap-2"
            >
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center overflow-hidden">
                {userProfileImage ? (
                  <img
                    src={userProfileImage || "/placeholder.svg"}
                    alt="Profil"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-4 h-4" />
                )}
              </div>
              <span className="hidden sm:inline">Profilim</span>
            </Button>

            {/* Admin için çerçeve butonu kaldırıldı */}
            {/* {isAdmin && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsFrameDialogOpen(true)}
                className="text-white hover:bg-white/20 flex items-center gap-2"
              >
                <ImagePlus className="w-4 h-4" />
                <span className="hidden sm:inline">Çerçeve</span>
              </Button>
            )} */}
          </div>

          {/* Orta kısım - Duyuru */}
          <div className="flex-1 mx-4">
            {isAdmin ? (
              <div className="flex flex-col md:flex-row items-center justify-center gap-2">
                <Input
                  type="text"
                  value={editAnnouncement}
                  onChange={(e) => setEditAnnouncement(e.target.value)}
                  placeholder="Duyuru metnini girin..."
                  className="flex-grow bg-white/20 border-none text-white placeholder:text-white/70"
                />
                <Button onClick={handleSaveAnnouncement} className="bg-white text-purple-800 hover:bg-gray-100">
                  Duyuruyu Kaydet
                </Button>
              </div>
            ) : (
              <p className="animate-pulse">{announcement || "Henüz bir duyuru yok."}</p>
            )}
          </div>

          {/* Sağ taraf - Boş alan (gelecekte başka özellikler için) */}
          <div className="w-16"></div>
        </div>
      </Card>

      <ProfileDialog
        isOpen={isProfileDialogOpen}
        onClose={() => setIsProfileDialogOpen(false)}
        userId={userId}
        userName={userName}
        currentProfileImage={userProfileImage}
      />

      {/* Admin için FrameDialog kaldırıldı */}
      {/* {isAdmin && (
        <FrameDialog isOpen={isFrameDialogOpen} onClose={() => setIsFrameDialogOpen(false)} currentUserId={userId} />
      )} */}
    </>
  )
}
