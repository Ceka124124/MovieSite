// components/youtube-sync-player.tsx
"use client"

import { useEffect, useRef } from "react"
import { ref, set } from "firebase/database"
import { db } from "@/lib/firebase"

interface YouTubeSyncPlayerProps {
  isAdmin: boolean
  userId: string
  videoState: {
    url: string
    isPlaying: boolean
    currentTime: number
    lastUpdatedBy: string
    lastAdminUpdateTime?: number
  }
}

declare global {
  interface Window {
    YT: any
    onYouTubeIframeAPIReady: () => void
  }
}

export default function YouTubeSyncPlayer({
  isAdmin,
  userId,
  videoState,
}: YouTubeSyncPlayerProps) {
  const playerRef = useRef<any>(null)
  const iframeRef = useRef<HTMLDivElement>(null)
  const videoStateRef = ref(db, "room/videoState")

  useEffect(() => {
    // YouTube IFrame API yüklemesi
    if (!window.YT || !window.YT.Player) {
      const tag = document.createElement("script")
      tag.src = "https://www.youtube.com/iframe_api"
      document.body.appendChild(tag)
      window.onYouTubeIframeAPIReady = () => initPlayer()
    } else {
      initPlayer()
    }

    function initPlayer() {
      const videoId = extractVideoId(videoState.url)
      if (!videoId || !iframeRef.current) return

      playerRef.current = new window.YT.Player(iframeRef.current, {
        videoId,
        playerVars: {
          autoplay: 0,
          controls: isAdmin ? 1 : 0,
          rel: 0,
          modestbranding: 1,
        },
        events: {
          onReady: (event: any) => {
            event.target.seekTo(videoState.currentTime, true)
            if (videoState.isPlaying) event.target.playVideo()
          },
          onStateChange: (event: any) => {
            if (!isAdmin) return
            const state = event.data
            if (state === window.YT.PlayerState.PLAYING) {
              syncState(true)
            } else if (state === window.YT.PlayerState.PAUSED) {
              syncState(false)
            }
          },
        },
      })
    }

    const syncInterval = setInterval(() => {
      const player = playerRef.current
      if (!player || typeof player.getCurrentTime !== "function") return

      const currentTime = player.getCurrentTime()
      const isPlaying =
        player.getPlayerState?.() === window.YT.PlayerState.PLAYING

      if (isAdmin && isPlaying) {
        set(videoStateRef, {
          ...videoState,
          currentTime,
          isPlaying,
          lastUpdatedBy: userId,
          lastAdminUpdateTime: Date.now(),
        })
      }

      // Kullanıcı senkronizasyonu
      if (!isAdmin && typeof videoState.lastAdminUpdateTime === "number") {
        const timeDiff = Math.abs(currentTime - videoState.currentTime)
        const recentlyUpdated =
          Date.now() - videoState.lastAdminUpdateTime < 5000

        if (timeDiff > 2 || recentlyUpdated) {
          player.seekTo(videoState.currentTime, true)
          if (videoState.isPlaying) player.playVideo()
          else player.pauseVideo()
        }
      }
    }, 2000)

    return () => clearInterval(syncInterval)
  }, [
    videoState.url,
    videoState.isPlaying,
    videoState.currentTime,
    videoState.lastAdminUpdateTime,
  ])

  function extractVideoId(url: string): string | null {
    const match = url.match(/(?:v=|\/)([0-9A-Za-z_-]{11})/)
    return match ? match[1] : null
  }

  function syncState(isPlaying: boolean) {
    const player = playerRef.current
    if (!player) return
    const currentTime = player.getCurrentTime?.()
    set(videoStateRef, {
      ...videoState,
      currentTime,
      isPlaying,
      lastUpdatedBy: userId,
      lastAdminUpdateTime: Date.now(),
    })
  }

  return <div ref={iframeRef} className="w-full h-full aspect-video" />
}
