// app/page.tsx
import { ChatRoom } from "@/components/chat-room"
import { Suspense } from "react" // Suspense'i import edin

export default function HomePage() {
  return (
    // ChatRoom bileşenini bir Suspense sınırı içine alın
    <Suspense fallback={<div>Yükleniyor...</div>}>
      <ChatRoom />
    </Suspense>
  )
}
